# 来源与迁移依据

核查日期：2026-10-23。只把实际读取到的公开材料作为证据；网页抓取可能存在缓存，不将页面中的星标或提交列表当作实时承诺。本文为独立归纳，未复制官网图像、源代码或字体。

## 主要依据

| 编号 | 可追溯来源 | 实际支持的结论 | 证据限制 |
|---|---|---|---|
| S1 | [Shopify Editions Winter ’26 官网](https://www.shopify.com/editions/winter2026) | 正式项目名为 Renaissance；栏目内容有独立标题与说明，可检索和导航 | 本轮可读取正文；Chrome 未连接，未现场验证滚动或截图参数 |
| S2 | [Shopify 官方发布](https://www.shopify.com/news/winter-26-edition-renaissance) | 以 RenAIssance 表达 AI 与商业工具的主题 | 是产品发布，不是详尽制作教程 |
| S3 | [Shopify 在 The One Show 的项目提交](https://www.oneclub.org/awards/theoneshow/-award/64482/the-renaissance-edition/) | 团队将古典艺术与现代工具并置，按章节组织可滚动画廊；设计开发早期协作控制时间轴；兼顾功能与惊喜 | 来自参赛方自述，经奖项页面发布；不把自报效果当因果实验 |
| S4 | [Arnaud Tanielian 制作线程镜像，2025-12-17](https://threadreaderapp.com/scrolly/2001335712982147307) | 制作者说明 three.js／R3F、分场景、时间轴工具与静态降级的实际制作方法 | 第一人称公开线程的第三方镜像，原帖本轮未成功打开；不是独立代码审计 |
| S5 | [Shopify 官方设计案例文章](https://www.shopify.com/blog/beautiful-websites) | Winter ’26 案例强调层级、节奏、目录与小惊喜；文字和插画协同 | 2026-09-21 编辑文章，不等于原团队的逐项规则 |
| S6 | [Codex 官方技能文档](https://learn.chatgpt.com/docs/build-skills) | SKILL.md 组织与 `.agents/skills` 发现路径、符号链接支持 | 不证明本包已被当前会话加载 |

不要混用 [Winter ’25 制作文章](https://www.shopify.com/news/how-we-built-boring-edition) 与 Winter ’26；Boring Edition 属于不同年份。本轮规则不引用前者作为本项目制作证据。

## 原站规律与迁移规则的区别

“强叙事主题、古典与现代并置、章节与内容相关、制作时可调节节奏、保留静态降级”有上述制作资料支持。“单个现代物件、适度不对称、冷色低干扰背景、字体融合、全屏／半屏／三分之一、180–360ms 与短滚动距离”是结合用户要求制定的 Vagus 艺术指导，不是 Shopify 官方原文或已测全站规律。原站允许复杂绘画，本项目的低干扰背景是为了修正 Vagus 旧稿的信息竞争，不能说 Shopify 每个背景都极简。

## GitHub 先例审阅

搜索范围：GitHub smooth scroll、Lenis、React Three Fiber、分场景与测试。agent-reach 的网页／开发路由已读取；本机未找到 agent-reach，gh 未认证，改用网页搜索与 GitHub 公开页面。没有下载或照搬代码，也未安装依赖。

| 项目 | 维护与许可证证据 | 测试／用法 | 可复用优势 | 明确局限与本轮决策 |
|---|---|---|---|---|
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | Poimandres；仓库页面约 33.2k 星；[MIT](https://github.com/pmndrs/react-three-fiber/blob/master/LICENSE)；[可见提交](https://github.com/pmndrs/react-three-fiber/commits/master/)列有 2026-08-25 ff3899d | README 有 Canvas／mesh 示例；[renderer 测试](https://github.com/pmndrs/react-three-fiber/blob/master/packages/fiber/tests/renderer.test.tsx)与 Jest 配置可读，本轮未运行 | 独立场景、可复用组件和状态驱动适合分镜拆分；也是 S4 明确提到的技术 | React 主版本需匹配，三维资产与 GPU 成本仍要承担；本轮借鉴分层思路，先交静态视觉，不引入依赖 |
| [darkroomengineering/lenis](https://github.com/darkroomengineering/lenis) | darkroom.engineering；页面约 16.8k 星；[MIT](https://github.com/darkroomengineering/lenis/blob/main/LICENSE)；[提交列表](https://github.com/darkroomengineering/lenis/commits/main/)可见 2026-08-05 eea7159 | README 有帧循环、锚点、集成与限制；已读 [package.json](https://github.com/darkroomengineering/lenis/blob/main/package.json)，根脚本未列 test；未运行或推断测试覆盖 | 滚动与动画同步已有成熟接入方式，不必自造滚轮处理 | iframe、嵌套容器和滚动吸附有具体限制；它不提供构图或艺术指导。本轮不安装，也没有证据证明 Winter ’26 使用它 |

星标仅是关注度线索。提交页与仓库主页缓存可能不一致，所以以上只是本轮“可见记录”，不是最新提交断言。正式实现时需重新核对版本、兼容性并做实际运行测试。

## 本轮本地证据

原对话附件已实际打开，两张都是暖金色思想者构图；文字卡横排／图片卡横排、复杂大厅、悬浮界面分别可见。用户后续明确否定黄色、复杂背景与横排图片卡，因此本轮将它们写成项目约束。附件拷贝保留在交付的 `evidence/` 中，不包含于通用安装包，不把这些生成图当作真实雕塑照片或正式作品数据。
