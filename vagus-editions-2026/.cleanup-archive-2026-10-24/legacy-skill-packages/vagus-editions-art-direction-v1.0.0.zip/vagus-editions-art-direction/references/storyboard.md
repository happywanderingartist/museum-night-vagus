# 分镜与构图指南

以下是本轮 Vagus 的迁移方案，不是对 Shopify 原站镜头逐帧复刻。先做可读的静态帧，再决定动画。

## 布局语法

| 类型 | 适合的内容 | 画面组织 | 阅读保护 |
|---|---|---|---|
| 全屏 | 开场或章节主题 | 主视觉场景贯穿画布，文字有独立安全区 | 不是全屏视频封面；导航与内容入口立即可见 |
| 半屏 | 主题与内容同等重要 | 约 50:50 或轻微偏置，允许主体越过虚拟分界 | 内容有稳定背景，文字不穿过人物脸和手 |
| 三分之一 | 阅读、列表或单件作品介绍 | 主视觉约占宽度 1/3，其余交给内容；左右可换 | 不是强行三列，也不是三张卡片 |

比例是主视觉占画面宽度的近似值；页面高度和停留长度取决于内容。只在宽屏母版上定方向，实际变窄时按阅读顺序重排，不能机械缩小整张图。

## 思想者章节分镜

| 帧 | 画面／布局 | 内容状态 | 动作与触发 | 结束／反向状态 |
|---|---|---|---|---|
| 01 建立 | 全屏冷紫蓝舞台；思想者偏右，标题大幅横向展开 | 顶栏、简介和三个竖排入口立即可读 | 初次出现可用很短淡入；不等待角色入场 | 静态也完整，返回顶部恢复同一构图 |
| 02 接近 | 主体收至约半屏，标题与图像建立更紧的轮廓关系 | 入口保持可点击，不随滚动消失 | 在约 0.25–0.6 视口内完成一次裁切／平移 | 用户停滚即停；反向滚动连续恢复 |
| 03 阅读 | 主体占约三分之一，内容区约三分之二 | 展示一件已核实作品的标题、实际内容与进入链接 | 背景和主体稳定，只在进入时短淡入 | 无作品内容时停在方案稿，不造案例 |
| 04 离开 | 下一章节以独立色块或清晰边界出现 | 当前作品可继续访问，目录可跳转 | 180–360ms 为定时过渡试制起点；滚动版短距离衔接 | 无动态偏好时直接切换文档流 |

以上时长和距离是推荐初值，必须在真实页面调整；未实测不能宣称“快速流畅”。避免同时做镜头旋转、文字逐字揭示、卡片横飞和背景变形。

## 图层合同

从底到顶：背景底色／低频光影 → 可选背景文字 → 主体与单个现代物件 → 前景可编辑标题 → 简介／导航／作品入口 → 焦点等交互状态。背景大字若被主体遮挡，前景仍需有完整可读的主题标题。

人物 PNG 可以将笔记本与人体作为一个可信接触关系的素材整体。若后续需要单独移动电脑，应重新制备匹配透视的物件与遮挡层，不能将生成图中的电脑粗切后假装获得完整可编辑三维资产。

## 素材生成示例

Use case: stylized-concept. Asset type: isolated editorial sculpture for a desktop portfolio hero. A pale cool limestone Thinker-like adult sculpture seated on a low integral stone plinth, leaning forward with one hand supporting the chin and the other naturally using exactly one unbranded dark cobalt laptop on the lap. Full head, hands, laptop and feet visible. Three-quarter view, quiet dry humor, convincing anatomy and contact. Cool neutral studio light, detailed stone but no dramatic gold light. True transparent background. One subject, one laptop, no other props, no lettering, no interface, no caption, no logo, no border, no room, no columns, no holograms. Compose the object centrally inside its own asset with enough margin; the UI layout will place it on the right separately.

原始素材提示词里不写页面导航和按钮文案。需要改变场景时保持主体／道具的命题，先调整占幅、裁切和背景重量，不能只换背景名词。
