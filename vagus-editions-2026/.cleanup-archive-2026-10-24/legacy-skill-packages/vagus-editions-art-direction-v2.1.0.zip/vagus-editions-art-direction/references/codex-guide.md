# 安装与调用

本机目标 D:/AI-Data/Shared/skills/vagus-editions-art-direction，经已有 C:/Users/15049/.agents/skills 联接发现。ZIP 顶层目录下直接含 SKILL.md。更新前比较版本、备份，更新后核对哈希。文件已安装不等于运行中会话刷新；技能选择器应确认版本。

[官方创建说明](https://learn.chatgpt.com/docs/build-skills)与[管理说明](https://learn.chatgpt.com/docs/enterprise/skills)区分本地、工作区和插件。Codex 可 $ 调用，ChatGPT 桌面有可用入口时可 @ 选择；本机安装不自动同步网页版／手机。账户有 Skills 上传入口可上传 ZIP；无入口时上传完整 Markdown 当聊天／项目规则，不称原生 Skill 安装或自动触发。具体能力以账户实际入口为准。

```text
使用 $vagus-editions-art-direction。
先读真实原稿、项目约束与 visual-study.md。
为思想者选构图路线，解释命题、主次和裁切；不靠增加自然背景填空。
保留 AI行业观察、置顶品牌导航、竖排文字入口和自然段简介。
先交黑白视觉重量稿和字体对照；获准制作后交无字素材、独立 UI、预览和短分镜。
不编作品、数量或经历；按检查表分开报告结构、视觉、行为与用户接受。
```

只分析不生成；只要提示词不运行；推进视觉不顺便发布。实现前审阅 GitHub 成熟先例，记维护、许可证、活动、测试、用法、优势与局限；历史记录不能替代引入前当前兼容性检查。不强制安装三维或滚动依赖。

默认 Chrome，异常先看连接与页面，再新建受控会话验证；未经授权不清空资料、重装或换浏览器。调试横条只证明附加状态，须用截图与导航验证；仍超时就披露，不能宣称永久修复。
