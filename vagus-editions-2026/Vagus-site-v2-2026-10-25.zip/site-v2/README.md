# Vagus · 连续展厅与 START / Hug

2026-10-25本批：保留首页与AI作品入口，接入手机固定的思想者局部动作，新增START与Hug独立项目页。START使用舞会与车票、酒红/靛紫；Hug使用日出水面、鼠尾草绿/暖金。UI文字和绘画素材分开，未重画母版。

## 打开

需要已有Node.js。双击start.cmd，保留终端窗口，在Google Chrome打开 http://127.0.0.1:4179 。如果预览已运行，直接用该地址。Ctrl+C停止。不要双击HTML使用file://：本地模块及GLB需要HTTP。服务仅监听本机，不是公网发布。无需npm install、登录、Blender或付费API。

- 首页：index.html；AI直达：index.html#ai；作品目录：index.html#works。
- START：start.html；Hug：hug.html。两页可以回展厅、互相切换并进入各自阅读目录。
- 手机从首次到后续始终固定，仅手指滑5秒、停2秒。关闭动态、系统减少动态、离屏或后台时暂停；模型加载失败保留绘画与普通HTML入口。
- START用独立路线线条衔接阅读，没有虚构手腕动画；Hug仅水面局部出现一次1.6秒光带，没有让整张背景晃动。

## 当前内容边界

这批完成页面布局、阅读结构、章节跳转和局部动效。真实产品截图、文章全文、本人职责与成果仍待接入，页面已明确标注。没有使用其他项目的数据填充；Hug未声明治疗效果。剩余展厅不包含在本批。思想者是绘画主体加2.5D手部和3D手机，不能作为完整3D人物或参考站同等完成度交付。

## 检查

在本目录运行 `node --test tests/*.test.mjs`。网站本身无安装依赖。scripts/browser-check.cjs属于本机浏览器检查，需要现有Playwright测试环境与Google Chrome，路径见脚本；便携包播放不依赖它。验证结果与未完成的验收见VALIDATION.md，许可与素材来源见SOURCES.md。原prototype-v1、历史ZIP和母版均保留。
