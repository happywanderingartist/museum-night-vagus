# Vagus · 完整页面试作 v3

本版先完成剩余页面，3D统一后置。原site-v2、灰模、模型源文件与历史ZIP保留；本版不加载Three、WebGL或模型。

## 打开

已有Node.js时，在本目录双击start.cmd，保留终端窗口，用Google Chrome打开 http://127.0.0.1:4182 。首页可进入探索；works.html是可筛选的作品速览。Ctrl+C停止本机服务。无需npm install或外部账户。file://直接打开时静态文字与普通链接仍在，模块交互需要本机服务。

## 页面

| 文件 | 内容 |
|---|---|
| index.html | 首页与9幕连续展厅 |
| works.html | 7个展示方向的搜索、分类与直达 |
| ai.html | 已提供的3个主题与原文接入位 |
| start.html / hug.html | 两个独立数字产品项目页 |
| xiaohongshu.html | 账号定位、选题与制作、真实代表笔记入口 |
| podcast.html | 节目定位、制作过程与原生音频播放器接入 |
| literature.html | 活动背景、策划、物料与现场证据结构 |
| visual.html | 真实个人作品接入位、独立网站艺术试稿画廊 |
| about.html | 已确认的介绍、项目索引、简历与联系入口 |

每个项目页可返回展厅/速览，并从页末进入前后项目。首页导航初始隐藏，下滚显现；系统减少动态优先。画廊代码支持方向键、Esc、关闭后回到原入口；真实材料缺失时不显示假音频、假指标或虚构履历。

## 真实材料

音频、文章原文URL、个人高清作品、简历、邮箱和具体履历尚未提供；页面结构完成不代表这些材料已经接入。把确认可公开的文件放入public/，再编辑assets/site-content.json，字段说明见CONTENT-GUIDE.md。服务器支持PDF和音频字节范围读取，便于文档与进度定位。网站艺术试稿与个人真实作品分组查看。

## 素材与源码

五幅新无字画面由内置image_gen生成，原始PNG保存在sources/artwork，网页WebP在assets，准确提示词与来源哈希在sources/。UI全部是HTML/CSS，不烧进图片。About中的匿名背影是原创艺术意象，不是真实作者照片。

HTML由scripts/build-pages.cjs和sources/templates生成。若需要重建，先备份手动修改的HTML，再修改生成器并运行 node scripts/build-pages.cjs 。构建不会重置assets/site-content.json。CSS与交互模块可直接编辑。图片格式转换脚本只用于重建网页WebP，播放网站不需要Python。

## 验证边界

离线代码/资源/片段与本机HTTP检查见VALIDATION.md。新版浏览器视觉检查没有完成：Chrome打开4182的自动审批因账户用量限制未能完成，动作未执行；没有改用其他浏览器或外部控制绕过。无截图被冒称为新版网页截图。

历史保留核验脚本scripts/preservation.py只在原项目运行，因为它读取未打入便携包的旧版本ZIP；其已执行结果在evidence/preservation.json。便携包内的Node测试、网站运行与素材重建不依赖历史目录。
